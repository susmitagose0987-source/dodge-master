const gameArea=document.getElementById("gameArea"),player=document.getElementById("player");
const scoreText=document.getElementById("score"),bestText=document.getElementById("best");
const startScreen=document.getElementById("startScreen"),gameOverScreen=document.getElementById("gameOver");
const startBtn=document.getElementById("startBtn"),restartBtn=document.getElementById("restartBtn"),finalScore=document.getElementById("finalScore");
const leftBtn=document.getElementById("leftBtn"),rightBtn=document.getElementById("rightBtn");
let playerX,score=0,bestScore=localStorage.getItem("dodgeBest")||0,gameRunning=false,enemies=[],enemyTimer,gameLoop,scoreTimer;
let keys={left:false,right:false}; bestText.textContent=bestScore;
function startGame(){startScreen.style.display="none";gameOverScreen.style.display="none";score=0;scoreText.textContent="0";enemies.forEach(e=>e.element.remove());enemies=[];player.style.display="block";playerX=gameArea.clientWidth/2;updatePlayer();gameRunning=true;enemyTimer=setInterval(createEnemy,750);scoreTimer=setInterval(()=>{if(gameRunning){score++;scoreText.textContent=score}},100);gameLoop=requestAnimationFrame(updateGame)}
function updatePlayer(){const w=player.offsetWidth,min=w/2,max=gameArea.clientWidth-w/2;if(keys.left)playerX-=6;if(keys.right)playerX+=6;playerX=Math.max(min,Math.min(max,playerX));player.style.left=playerX+"px"}
function createEnemy(){if(!gameRunning)return;const enemy=document.createElement("div");enemy.className="enemy";const size=38,x=Math.random()*(gameArea.clientWidth-size);enemy.style.left=x+"px";enemy.style.top="-50px";gameArea.appendChild(enemy);enemies.push({element:enemy,x,y:-50,speed:3+Math.random()*2})}
function collision(a,b){const r1=a.getBoundingClientRect(),r2=b.getBoundingClientRect();return !(r1.right<r2.left||r1.left>r2.right||r1.bottom<r2.top||r1.top>r2.bottom)}
function updateGame(){if(!gameRunning)return;updatePlayer();enemies.forEach(e=>{e.y+=e.speed;e.element.style.top=e.y+"px";if(collision(player,e.element))endGame()});enemies=enemies.filter(e=>{if(e.y>gameArea.clientHeight+60){e.element.remove();return false}return true});gameLoop=requestAnimationFrame(updateGame)}
function endGame(){if(!gameRunning)return;gameRunning=false;clearInterval(enemyTimer);clearInterval(scoreTimer);cancelAnimationFrame(gameLoop);finalScore.textContent=score;if(score>bestScore){bestScore=score;localStorage.setItem("dodgeBest",bestScore);bestText.textContent=bestScore}gameOverScreen.style.display="flex"}
document.addEventListener("keydown",e=>{if(e.key==="ArrowLeft"||e.key.toLowerCase()==="a")keys.left=true;if(e.key==="ArrowRight"||e.key.toLowerCase()==="d")keys.right=true});
document.addEventListener("keyup",e=>{if(e.key==="ArrowLeft"||e.key.toLowerCase()==="a")keys.left=false;if(e.key==="ArrowRight"||e.key.toLowerCase()==="d")keys.right=false});
function pressLeft(e){e.preventDefault();keys.left=true}function releaseLeft(e){e.preventDefault();keys.left=false}
function pressRight(e){e.preventDefault();keys.right=true}function releaseRight(e){e.preventDefault();keys.right=false}
leftBtn.addEventListener("mousedown",pressLeft);leftBtn.addEventListener("mouseup",releaseLeft);leftBtn.addEventListener("mouseleave",releaseLeft);
leftBtn.addEventListener("touchstart",pressLeft);leftBtn.addEventListener("touchend",releaseLeft);
rightBtn.addEventListener("mousedown",pressRight);rightBtn.addEventListener("mouseup",releaseRight);rightBtn.addEventListener("mouseleave",releaseRight);
rightBtn.addEventListener("touchstart",pressRight);rightBtn.addEventListener("touchend",releaseRight);
startBtn.addEventListener("click",startGame);restartBtn.addEventListener("click",startGame);
