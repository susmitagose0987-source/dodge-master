DODGE MASTER

How to play:
1. Open index.html in Chrome.
2. Click PLAY GAME.
3. PC: Arrow Left/Right or A/D.
4. Mobile: use the on-screen buttons.

Publish:
Upload index.html, style.css and game.js to a GitHub repository.
Enable GitHub Pages from Settings > Pages > Deploy from a branch > main > /root.
